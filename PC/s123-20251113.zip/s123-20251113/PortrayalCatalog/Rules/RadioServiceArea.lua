-- Main entry point for RadioServiceArea
function RadioServiceArea(feature, featurePortrayal, contextParameters)
	local color
	if feature.Code == 'RadioServiceArea' then
		color = 'LITGN'
	elseif feature.Code == 'IndeterminateZone' then
		color = 'LITYW'
	else 
	end
    featurePortrayal:AddInstructions('ViewingGroup:31020;DrawingPriority:13;DisplayPlane:OverRADAR;')
    featurePortrayal:AddInstructions('ColorFill:'..color..',0.75')
	featurePortrayal:SimpleLineStyle('solid',0.5,'CHBLK')
	featurePortrayal:AddInstructions('LineInstruction:_simple_')
	return 31020
end