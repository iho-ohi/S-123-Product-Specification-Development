require 'SectorLimit'

-- Main entry point for ConnectivitySubscriptionArea
function ConnectivitySubscriptionArea(feature, featurePortrayal, contextParameters)
	if feature.PrimitiveType == PrimitiveType.Point then
		featurePortrayal:AddInstructions('ViewingGroup:31020;DrawingPriority:14;DisplayPlane:OverRADAR;')
		SectorLimit(feature, featurePortrayal, contextParameters)
	end
	return 31020
end
