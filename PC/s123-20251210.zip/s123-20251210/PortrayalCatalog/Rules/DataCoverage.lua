function DataCoverage(feature, featurePortrayal, contextParameters)
	featurePortrayal:AddInstructions('ViewingGroup:31020;DrawingPriority:3;DisplayPlane:UnderRadar;NullInstruction')
    return 31020
end