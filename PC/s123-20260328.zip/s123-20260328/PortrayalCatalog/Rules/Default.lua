-- Default portrayal rules file.  Called when rule file cannot be found.
-- #119

-- Main entry point for feature type.
function Default(feature, featurePortrayal, contextParameters)

	if (feature.PrimitiveType == PrimitiveType.Point or feature.PrimitiveType == PrimitiveType.MultiPoint) then
		-- Simplified and paper chart points use the same symbolization
		featurePortrayal:AddInstructions('ViewingGroup:21010;DrawingPriority:15')
		featurePortrayal:AddInstructions('PointInstruction:QUESMRK1')
	elseif (feature.PrimitiveType == PrimitiveType.Curve) then
		featurePortrayal:AddInstructions('ViewingGroup:21010;DrawingPriority:15')
		featurePortrayal:AddInstructions('LineInstruction:QUESMRK1')
	elseif (feature.PrimitiveType == PrimitiveType.Surface) then
		featurePortrayal:AddInstructions('ViewingGroup:21010;DrawingPriority:15;DisplayPlane:UnderRadar')
		featurePortrayal:AddInstructions('PointInstruction:QUESMRK1')
		featurePortrayal:AddInstructions('LineInstruction:QUESMRK1')
	end
	return "21010"
end
